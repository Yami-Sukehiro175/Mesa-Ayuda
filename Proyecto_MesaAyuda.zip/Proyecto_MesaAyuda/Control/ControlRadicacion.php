
<?php
session_start();
include 'ControlRequerimientos.php';
include 'ControlDetalleRequerimientos.php';
include '../Modelo/Requerimientos.php';
include '../Modelo/DetalleRequerimientos.php';
include 'ControlConexion.php';
$fkArea=$_POST['txtAreaRequerimiento'];
$objRequerimientos= new Requerimientos('', $fkArea);
$objControlRequerimientos= new ControlRequerimientos($objRequerimientos);
$objControlRequerimientos->guardar();
$idDetalle='';
$fecha=$_POST['txtfecha'];
$observacion=$_POST['txtobservacion'];
$fkReq=$objControlRequerimientos->registroreciente();
$fkEstado='1';
$fkEmple=$_SESSION['idempleado'];
$fkEmpleAsignado='NULL';
$objDetalleRequerimientos=new DetalleRequerimientos($idDetalle, $fecha, $observacion, $fkReq, $fkEstado, $fkEmple, $fkEmpleAsignado);
$objControlDetalleRequerimientos= new ControlDetalleRequerimientos($objDetalleRequerimientos);
$objControlDetalleRequerimientos->guardar();
print_r($_POST);
$objRequerimientos1= new DetalleRequerimientos(17,'' , '','' ,'' ,'' ,'');

$objControlDetalleRequerimientos1= new ControlDetalleRequerimientos($objRequerimientos1);
$aux=$objControlDetalleRequerimientos1->consultar();
print_r($aux);
//header('Refresh: 1; URL=../Vista/Inicio.php');
?>

