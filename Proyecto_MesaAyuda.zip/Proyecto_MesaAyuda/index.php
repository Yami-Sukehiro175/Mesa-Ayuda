
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <textarea id="w3review" name="w3review" rows="4" cols="50">
At w3schools.com you will learn how to make a website. They offer free tutorials in all web development technologies.
</textarea>
       
        <?php
          $hoy = date('Y-m-d H:i:s');
        
        //$laid=$req->registroreciente();
       // echo $laid;
        //date_default_timezone_set('America/Bogota');
        $hoy = date('Y-m-d H:i:s');
        include './Control/ControlConexion.php';
        include './Modelo/Requerimientos.php';
        include './Control/ControlRequerimientos.php';
        include './Control/ControlDetalleRequerimientos.php';
        include './Modelo/DetalleRequerimientos.php';
        include './Modelo/CargoEmpleados.php';
        include 'Control/ControlCargoEmpleados.php';
        
        $cargosem= new CargoEmpleados(4,'2',$hoy,$hoy);
        $objcargoempl= new ControlCargoEmpleados($cargosem);
       $mt= $objcargoempl->borrar();
       print_r($mt);
        
        
        
      
        
       /*
                //echo $hoy;
        $detreq=new DetalleRequerimientos('NULL',$hoy,'NO funciona el pc',$laid, '2', '2','NULL');
        //$emp=new Empleados('2', 'YUGI Moto', 'RUTA FOTOs', 'ROJA HOJs', '526566', '659898', '124', -40.54825, 55.25485, 'NULL', 30);
      $objetoreq= new ControlDetalleRequerimientos($detreq);
      $objetoreq->guardar();
      print_r($detreq);
     
        
    
      
  
       /*
        $cargo = new Cargos('','Barrendero');
                $objcargo=new ControlCargos($cargo);
                $objcargo->guardar();
       /*$sw;
        $cargo2=new Cargos(1, '');
       $objcargo2= new ControlCargos($cargo2);
       $objcargo2->consultar();
       print_r($objcargo2);
       $cargo3=new Cargos(2,'Pescador');
       $objcargos3=new ControlCargos($cargo3);
       $objcargos3->modificar();
       
       $Z=$objcargos3->listar();
       print_r($Z);
       
          $cargo4=new Cargos(3,'');
       $objcargos4=new ControlCargos($cargo4);
       $objcargos4->borrar();
       /*
        $areas= new Areas('50','Cafeteria','NULL');
        $objArea= new ControlAreas($areas);
        print_r($areas);
       
        $sw=$objArea->guardar();
        echo' Tu Resultado es: '.$sw;
        $areas2= new Areas('50','NULL','NULL');
        $objArea2= new ControlAreas($areas2);
        $objArea2->consultar();
        echo'La consulta es';
         $areas3= new Areas('50','Cosos','2');
        $objArea3= new ControlAreas($areas3);
        $objArea3->modificar();
        print_r($objArea3);
        $areas4= new Areas('50','Cosos','2');
         $objArea4= new ControlAreas($areas4);
        $objArea4->borrar();
        $swa=$objArea4->listar();
        print_r($swa);
        */
        
        // put your code here
        ?>
        <!-- Section: form gradient -->
<section class="form-gradient mb-5">

  <!--Form with header-->
  <div class="card">

    <!--Header-->
    <div class="header peach-gradient">

      <div class="row d-flex justify-content-center">
        <h3 class="white-text mb-0 py-5 font-weight-bold">Contact Us</h3>
      </div>

    </div>
    <!--Header-->

    <div class="card-body mx-4">

      <div class="md-form">
        <i class="fas fa-user prefix grey-text"></i>
        <input type="text" id="form104" class="form-control">
        <label for="form104">Your name</label>
      </div>

      <div class="md-form">
        <i class="fas fa-envelope prefix grey-text"></i>
        <input type="text" id="form105" class="form-control">
        <label for="form105">Your email</label>
      </div>

      <div class="md-form">
        <i class="fas fa-tag prefix grey-text"></i>
        <input type="text" id="form106" class="form-control">
        <label for="form106">Subject</label>
      </div>

      <div class="md-form">
        <i class="fas fa-pencil-alt prefix grey-text"></i>
        <textarea id="form107" class="md-textarea form-control" rows="5"></textarea>
        <label for="form107">Your message</label>
      </div>


      <!--Grid row-->
      <div class="row d-flex align-items-center mb-3 mt-4">

        <!--Grid column-->
        <div class="col-md-12">
          <div class="text-center">
            <button type="button" class="btn btn-grey btn-rounded z-depth-1a">Send</button>
          </div>
        </div>
        <!--Grid column-->

      </div>
      <!--Grid row-->
    </div>

  </div>
  <!--/Form with header-->

</section>
<!-- Section: form gradient -->
<!-- Section: form dark -->
<section class="form-dark mb-5">

  <!--Form without header-->
  <div class="card card-image" style="background-image: url('https://mdbootstrap.com/img/Photos/Others/pricing-table%20(7).jpg');">
    <div class="text-white rgba-stylish-strong py-5 px-5 z-depth-4">

      <!--Header-->
      <div class="text-center">
        <h3 class="white-text mb-5 mt-4 font-weight-bold text-uppercase"><strong>Contact</strong> <a class="green-text font-weight-bold"><strong>
              Us</strong></a></h3>
      </div>

      <div class="md-form">
        <input type="text" id="form100" class="form-control">
        <label for="form100">Your name</label>
      </div>

      <div class="md-form">
        <input type="text" id="form101" class="form-control">
        <label for="form101">Your email</label>
      </div>

      <div class="md-form">
        <input type="text" id="form102" class="form-control">
        <label for="form102">Subject</label>
      </div>

      <div class="md-form">
        <textarea id="form103" class="md-textarea form-control" rows="5"></textarea>
        <label for="form103">Your message</label>
      </div>

      <!--Grid row-->
      <div class="row d-flex align-items-center">

        <!--Grid column-->
        <div class="text-center col-md-12 mt-3 mb-2">
          <button type="button" class="btn btn-success btn-block btn-rounded z-depth-1">Send</button>
        </div>
        <!--Grid column-->
      </div>
      <!--Grid row-->

    </div>
  </div>
  <!--/Form without header-->

</section>
<!-- Section: form dark -->
        <a href="./Vista/Radicacion.php">Ir a Radicar Requerimiento</a>
        <a href="./Vista/VistaCrudAreas.php">Ii a C.R.U.D de Área</a>
        <a href="./Vista/VistaCrudCargos.php">Ii a C.R.U.D de Cargo</a>
        <a href="./Vista/VistaCrudEmpleados.php">Ii a C.R.U.D de Empleados</a>
         <a href="./Vista/VistaCrudCargosEmpleados.php">Ii a C.R.U.D de Cargo Por Empleado</a>
    </body>
</html>
