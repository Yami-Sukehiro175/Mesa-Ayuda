
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
     
       
        <?php
    $sw=true;
?>        
  
        
        
        <?php
        if($sw)
            echo'<h1>Prueba</h1>';
            ?>
        
        <?php
       /*
                //echo $hoy;
        $detreq=new DetalleRequerimientos('NULL',$hoy,'NO funciona el pc',$laid, '2', '2','NULL');
        //$emp=new Empleados('2', 'YUGI Moto', 'RUTA FOTOs', 'ROJA HOJs', '526566', '659898', '124', -40.54825, 55.25485, 'NULL', 30);
      $objetoreq= new ControlDetalleRequerimientos($detreq);
      $objetoreq->guardar();
      print_r($detreq);
     
        
    
      
  
       /*
        $cargo = new Cargos('','Barrendero');
                $objcargo=new ControlCargos($cargo);
                $objcargo->guardar();
       /*$sw;
        $cargo2=new Cargos(1, '');
       $objcargo2= new ControlCargos($cargo2);
       $objcargo2->consultar();
       print_r($objcargo2);
       $cargo3=new Cargos(2,'Pescador');
       $objcargos3=new ControlCargos($cargo3);
       $objcargos3->modificar();
       
       $Z=$objcargos3->listar();
       print_r($Z);
       
          $cargo4=new Cargos(3,'');
       $objcargos4=new ControlCargos($cargo4);
       $objcargos4->borrar();
       /*
        $areas= new Areas('50','Cafeteria','NULL');
        $objArea= new ControlAreas($areas);
        print_r($areas);
       
        $sw=$objArea->guardar();
        echo' Tu Resultado es: '.$sw;
        $areas2= new Areas('50','NULL','NULL');
        $objArea2= new ControlAreas($areas2);
        $objArea2->consultar();
        echo'La consulta es';
         $areas3= new Areas('50','Cosos','2');
        $objArea3= new ControlAreas($areas3);
        $objArea3->modificar();
        print_r($objArea3);
        $areas4= new Areas('50','Cosos','2');
         $objArea4= new ControlAreas($areas4);
        $objArea4->borrar();
        $swa=$objArea4->listar();
        print_r($swa);
        */
        
        // put your code here
        ?>
        <form action="./Control/ControlLogin.php" method="POST">
        email
        <input type="email" name="txtemailingreso">
       documento
        <input type="text" name="txtdocumentoingreso">
           <input type="submit" style="font-family:'Maiandra GD'" value="login" id="enviar" style="text-align: center;">
<!-- Section: form dark -->
        <a href="./Vista/Radicacion.php">Ir a Radicar Requerimiento</a>
        <a href="./Vista/VistaCrudAreasAux.php">Ii a C.R.U.D de Área</a>
        <a href="./Vista/VistaCrudCargosAux.php">Ii a C.R.U.D de Cargo</a>
        <a href="./Vista/VistaCrudEmpleadosAux.php">Ii a C.R.U.D de Empleados</a>
         <a href="./Vista/VistaCrudCargosEmpleadosAux.php">Ii a C.R.U.D de Cargo Por Empleado</a>
         <a href="./Vista/VistaRequerimientosSinAsignar.php">Ir a Requerimientos sin asignar</a>
        </form>
    </body>
</html>
