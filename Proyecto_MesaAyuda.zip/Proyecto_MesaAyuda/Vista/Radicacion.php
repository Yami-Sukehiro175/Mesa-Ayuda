<!DOCTYPE html>
<?php
date_default_timezone_set('America/Bogota');
$hoy = date('Y-m-d H:i:s');
?>
<html>
    <head>
        <meta charset="UTF-8">
      <link href="../css/bootstrap.css" rel="stylesheet" type="text/css"/>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Radicación requerimientos</title>
    </head>
    <body>
    <center> <H1 style=" font-style: bold; font-size: 65px;font-family:'Bradley Hand ITC'" >Radicación de Requerimientos</H1> </center>  
    <div class="container">
        <div class="table-wrapper">
            <div class="table-title">
                <div class="row">
                    <div class="col-sm-4">
                        <a href="../index.php" class="btn btn-secondary add-new"><i class="fa fa-arrow-left"></i> Volver al indice</a>
                        <a href="../Control/ControlLogout.php" class="btn btn-secondary add-new"><i class="fa fa-arrow-left"></i> Cerrar Sesión</a>
                    </div>
                </div>
            </div>
            <form action="../Control/ControlRadicacion.php" method="POST">
                <div class="row">
                    <div class="col-md-6">
                        <label><p style=" font-size: 45px;font-family:'Britannic'" >Fecha Actual</p></label>
                        <input type="datetime-local" name="txtfecha" id="codigo" class='form-control' maxlength="20" value="<?php echo'' . $hoy; ?>">
                    </div>
                    <br>
                    <div class="col-md-8">
                        <label><p style=" font-size: 45px;font-family:'Britannic'" >Escriba aquí en detalle su requerimiento:</p></label>
                        <div class="md-form amber-textarea active-amber-textarea-2" >
                        <i class="fas fa-pencil-alt prefix" src="C:/xampp/htdocs/Proyecto_MesaAyuda/bootstrap-icons-1.4.1/pencil.svg"></i>
                        <textarea id="form24" class="md-textarea form-control" rows="3" maxlength="4000" name="txtobservacion"></textarea>
                      </div>
                       <!--<input type="textarea" name="txtobservacion" id="nombre" class='form-control' maxlength="100">-->
                    </div>
                    <center>
                    <div div class="col-md-4">
                        <label><p style=" font-size: 45px;font-family:'Britannic'" >Seleccione el área a la cual desea remitir su requerimiento</p></label>
                        <select name="txtAreaRequerimiento" class="form-select form-select-lg mb-4"  aria-label=".form-select-lg example">
                            <option value="30">Mantenimiento</option>
                            <option value="20">Gestión Humana</option>
                            <option value="10">Informática</option>
                        </select>
                    </div>
                    </center>
                    <center>
                        <input type="submit" style="font-family:'Britannic'" value="Radicar Requerimiento" id="enviar" style="text-align: center;">
                        <br>
                    </center>
                    <br>
                </div>
            </form>
        </div>
    </div>


</body>
</html>
