<?php
include '../Control/ControlDetalleRequerimientos.php';
include '../Modelo/DetalleRequerimientos.php';
include '../Control/ControlConexion.php';
include '../Control/ControlEmpleados.php';
include '../Control/ControlAreas.php';
include '../Modelo/Empleados.php';
include '../Modelo/Areas.php';
include '../Modelo/Requerimientos.php';
include '../Control/ControlRequerimientos.php';
$objDetalleRequerimientos= new DetalleRequerimientos('', '', '', '','1', '', '');
$objControlDetalleRequerimientos = new ControlDetalleRequerimientos($objDetalleRequerimientos);
$MatrizRequerimientos=$objControlDetalleRequerimientos->consultarportipo();
//print_r($MatrizRequerimientos);
//print_r($objDetalleRequerimientos);
?>

<html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title></title>
    </head>
    <body>
<table border="1" class="table table-bordered table-striped">
            <tr border="1">
                <td>ID Detalle</td>
                <td>Fecha Detalle</td>
                 <td>Observacion</td>
                  <td>Requerimiento</td>
                  <td>Area asignada</td>
                   <td>Estado</td>
                    <td>Empleado Que radicó</td>
                     <td>Empleado Asignado</td>
            </tr>
               <br>
            <?php
            //creacion de la tabla con la Matriz de Area y el ForEach
            foreach ($MatrizRequerimientos as $Requerimientos) {
                $objRequerimientoR= new Requerimientos($Requerimientos->getFkReq(), '');
                $objControlRequerimientos= new ControlRequerimientos($objRequerimientoR);
               $objControlRequerimientos->consultar();
                 $objArea= new Areas($objRequerimientoR->getFkArea(), '', '');
                $objControlArea= new ControlAreas($objArea);
                 $objControlArea->consultar();
                 $NombreArea= $objArea->getNombre();
                 $objEmpleados3= new Empleados($Requerimientos->getFkEmple(), '','', '', '', '', '', '', '', '', '');
                 $objControlEmpleados3= new ControlEmpleados($objEmpleados3);
                 $objControlEmpleados3->consultar();
                 $NombreEmpleado= $objEmpleados3->getNombre();
                ?>
                <tr border="1">
                    <?php
                    echo '<td>' . $Requerimientos->getIdDetalle(). '</td>';
                    echo '<td>' . $Requerimientos->getFecha() . '</td>';
                    echo '<td>' . $Requerimientos->getObservacion() . '</td>';
                    echo '<td>' . $Requerimientos->getIdDetalle() . '</td>';
                    echo '<td>' . $NombreArea. '</td>';
                    echo '<td>Radicado</td>';
                    echo '<td>' . $NombreEmpleado . '</td>';
                    echo '<td>Sin Asignar</td>';
                    ?>
                    <?php
                }
                ?>

            </tr>
        </table>

        </form>
    </body>
</html>