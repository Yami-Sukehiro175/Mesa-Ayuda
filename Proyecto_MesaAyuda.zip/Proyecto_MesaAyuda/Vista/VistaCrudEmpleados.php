<!DOCTYPE html>
<?php
//inclusion de Algunas clases de Control y Modelo para la creacion de una tabla con todos los registros de Area
include '../Control/ControlAreas.php';
include '../Modelo/Areas.php';
include '../Control/ControlConexion.php';
include '../Control/ControlEmpleados.php';
include '../Modelo/Empleados.php';
$objEmpleados= new Empleados('', '', '','', '','' ,'','' ,'' ,'' ,'' );
$objControlEmpleados= new ControlEmpleados($objEmpleados);
$MatrizEmpleados=$objControlEmpleados->listar();
$objareas1 = new Areas('', '','');
$objControlAreas = new ControlAreas($objareas1);
$MatrizAreas = $objControlAreas->listar(); // se crea la matriz de areas y despues se usara foreach para imprimri cada dato en la tabla en su correspondiente posicion
?>
<html>

    <head>
        <meta charset="UTF-8">
        <link href="../css/bootstrap.css" rel="stylesheet" type="text/css"/>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Crud Área</title>
    </head>

    <body>
    <center> <H1 style=" font-style: bold; font-size: 65px;font-family:'Bookman Old Style'" >Prueba 1 Php Juan José Díez Rico</H1> </center>
Cooper
    <center> <div class="col-sm-8"><center><h2>Listado Total de Áreas Registradas</h2></center></div> </center>
    <center>
        <table border="1" class="table table-bordered table-striped">
            <tr border="1">
                <td>ID Área</td>
                <td>Nombre Área</td>
            </tr>
            <br>
            <?php
            //creacion de la tabla con la Matriz de Area y el ForEach
            foreach ($MatrizAreas as $Area1) {
                ?>
                <tr border="1">
                    <?php
                    echo '<td>' . $Area1->getIdArea() . '</td>';
                    echo '<td>' . $Area1->getNombre() . '</td>';
                    ?>
                    <?php
                }
                ?>

            </tr>
        </table>
    </center>
    <div class="container">
        <div class="table-wrapper">
            <div class="table-title">
                <div class="row">
                    <div class="col-sm-12"><center><h2 style="font-size: 65px ; font-family: 'Bookman Old Style'">Ingreso de Datos Inicial</h2></center></div>
                    <div class="col-sm-4">
                        <a href="../index.php" class="btn btn-secondary add-new"><i class="fa fa-arrow-left"></i> Volver al indice</a>
                    </div>
                </div>
            </div>

            <form action="VistaCrudEmpleadosAux.php" method="POST">


                <div class="row">
                    <div class="col-md-6">
                        <label><p style=" font-size: 45px;font-family:'Maiandra GD'" >identificación Empleado</p></label>
                        <input type="text" name="txtidempleado" id="codigo" class='form-control' maxlength="10">
                    </div>

                    <div class="col-md-6">
                        <label><p style=" font-size: 45px;font-family:'Maiandra GD'" >Nombre Empleado:</p></label>
                        <input type="text" name="txtnombreEmpleado" id="nombre" class='form-control' maxlength="50">
                    </div>
                    
                     <div class="col-md-6">
                        <label><p style=" font-size: 45px;font-family:'Maiandra GD'" >Agregar Foto:</p></label>
                        <input type="file" name="txtfoto" id="nombre" class='form-control'  accept=".jpg, .jpeg, .png" value="C:\Users\Rosy\Desktop\Orden examenes.pdf">
                    </div>
                    <div class="col-md-6">
                        <label><p style=" font-size: 45px;font-family:'Maiandra GD'" >Agregar Hoja de vida:</p></label>
                        <input type="file" name="txthojavida" id="nombre" class='form-control' accept=".jpg, .jpeg, .png, .pdf" value="C:\Users\Rosy\Desktop\Orden examenes.pdf">
                    </div>
                    <div class="col-md-6">
                        <label><p style=" font-size: 45px;font-family:'Maiandra GD'" >Teléfono:</p></label>
                        <input type="text" name="txttelefono" id="nombre" class='form-control' maxlength="50">
                    </div>
                    <div class="col-md-6">
                        <label><p style=" font-size: 45px;font-family:'Maiandra GD'" >Correo Electrónico:</p></label>
                        <input type="email" name="txtemail" id="nombre" class='form-control' maxlength="50">
                    </div>
                    <div class="col-md-6">
                        <label><p style=" font-size: 45px;font-family:'Maiandra GD'" >Dirección:</p></label>
                        <input type="text" name="txtdireccion" id="nombre" class='form-control' maxlength="50">
                    </div>
                    <div class="col-md-6">
                        <label><p style=" font-size: 45px;font-family:'Maiandra GD'" >Coordenada X:</p></label>
                        <input type="text" name="txtX" id="nombre" class='form-control' maxlength="50">
                    </div>
                     <div class="col-md-6">
                        <label><p style=" font-size: 45px;font-family:'Maiandra GD'" >Coordenada Y:</p></label>
                        <input type="text" name="txtY" id="nombre" class='form-control' maxlength="50">
                    </div>
  
                     <div class="col-md-6">
                        <label><p style=" font-size: 45px;font-family:'Maiandra GD'" >Empleado Encargado:</p></label>
                         <select name="txtEmpleadoEncargado" class="form-select form-select-lg mb-4"  aria-label=".form-select-lg example">
                        <?php foreach ($MatrizEmpleados as $Empleados){
                            
                        ?>
                        
                       
                            <?php
                            echo '<option value='.$Empleados->getIdEmpleado().'>'.$Empleados->getNombre().'</option>';
                        ?>
                            
                           <?php
                        }?>
                             <option value="NULL" selected="selected">Jefe Sin Asignar</option>
                        </select>
                        <!--<input type="text" name="txtnombrearea" id="nombre" class='form-control' maxlength="50">-->
                    </div>
                    <div class="col-md-6">
                        <label><p style=" font-size: 45px;font-family:'Maiandra GD'" >Area a asignar:</p></label>
                         <select name="txtarea" class="form-select form-select-lg mb-4"  aria-label=".form-select-lg example">
                        <?php foreach ($MatrizAreas as $Areas){
                            
                        ?>
                        
                       
                            <?php
                            echo '<option value='.$Areas->getIdArea().'>'.$Areas->getNombre().'</option>';
                        ?>
                            
                           <?php
                        }?>
                             <option value="NULL" selected="selected">Área sin Asignar</option>
                        </select>
                        <!--<input type="text" name="txtnombrearea" id="nombre" class='form-control' maxlength="50">-->
                    </div>
                    <br>
                    <br>

                    <br>
                    <center>
                        <br>
                        <br>

                        <input type="submit" style="font-family:'Maiandra GD'" value="Enviar Datos Para Hacer Crud" id="enviar" style="text-align: center;">
                        <br>
                    </center>
                    <br>


                </div>
            </form>

        </div>
    </div>

</body>
</html>

