<!DOCTYPE html>
<?php
//inclusion de Algunas clases de Control y Modelo para la creacion de una tabla con todos los registros de Area
include '../Control/ControlCargos.php';
include '../Modelo/Cargos.php';
include '../Control/ControlConexion.php';
include '../Control/ControlEmpleados.php';
include '../Modelo/Empleados.php';
$objEmpleados= new Empleados('', '', '','', '','' ,'','' ,'' ,'' ,'' );
$objControlEmpleados= new ControlEmpleados($objEmpleados);
$MatrizEmpleados=$objControlEmpleados->listar();
$objcargos = new Cargos('', '');
$objControlCargos = new ControlCargos($objcargos);
$MatrizCargos = $objControlCargos->listar();
$objCargos// se crea la matriz de areas y despues se usara foreach para imprimri cada dato en la tabla en su correspondiente posicion
?>
<html>

    <head>
        <meta charset="UTF-8">
        <link href="../css/bootstrap.css" rel="stylesheet" type="text/css"/>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Crud Área</title>
    </head>

    <body>
    <center> <H1 style=" font-style: bold; font-size: 65px;font-family:'Bookman Old Style'" >Prueba 1 Php Juan José Díez Rico</H1> </center>
Cooper
    <center> <div class="col-sm-8"><center><h2>Listado Total de Áreas Registradas</h2></center></div> </center>
    <center>
        <table border="1" class="table table-bordered table-striped">
            <tr border="1">
                <td>Identificacion Cargo</td>
                <td>Nombre Cargo</td>
            </tr>
            <br>
            <?php
            //creacion de la tabla con la Matriz de Area y el ForEach
            foreach ($MatrizCargos as $Cargos) {
                ?>
                <tr border="1">
                    <?php
                    echo '<td>' . $Cargos->getIdCargo() . '</td>';
                    echo '<td>' . $Cargos->getNombreCargo() . '</td>';
                    ?>
                    <?php
                }
                ?>

            </tr>
        </table>
    </center>
    <div class="container">
        <div class="table-wrapper">
            <div class="table-title">
                <div class="row">
                    <div class="col-sm-12"><center><h2 style="font-size: 65px ; font-family: 'Bookman Old Style'">Ingreso de Datos Inicial</h2></center></div>
                    <div class="col-sm-4">
                        <a href="../index.php" class="btn btn-secondary add-new"><i class="fa fa-arrow-left"></i> Volver al indice</a>
                    </div>
                </div>
            </div>

            <form action="VistaCrudCargosAux.php" method="POST">


                <div class="row">
                    <div class="col-md-6">
                        <label><p style=" font-size: 45px;font-family:'Maiandra GD'" >Fecha Inicio</p></label>
                        <input type="date" name="txtfechainicio" id="codigo" class='form-control' maxlength="10">
                    </div>

                    <div class="col-md-6">
                        <label><p style=" font-size: 45px;font-family:'Maiandra GD'" >Fecha Finalización:</p></label>
                        <input type="date" name="txtfechafin" id="nombre" class='form-control' maxlength="50">
                    </div>
                     <div class="col-md-6">
                        <label><p style=" font-size: 45px;font-family:'Maiandra GD'" >Empleado Para Cargo:</p></label>
                         <select name="txtEmpleado" class="form-select form-select-lg mb-4"  aria-label=".form-select-lg example">
                        <?php foreach ($MatrizEmpleados as $Empleados){
                            
                        ?>
                        
                       
                            <?php
                            echo '<option value='.$Empleados->getIdEmpleado().'>'.$Empleados->getNombre().'</option>';
                        ?>
                            
                           <?php
                        }?>
                             <option value="NULL" selected="selected">Encargado Sin Asignar</option>
                        </select>
                        <!--<input type="text" name="txtnombrearea" id="nombre" class='form-control' maxlength="50">-->
                    </div>
                       <div class="col-md-6">
                        <label><p style=" font-size: 45px;font-family:'Maiandra GD'" >Cargo a Asignar:</p></label>
                         <select name="txtcargo" class="form-select form-select-lg mb-4"  aria-label=".form-select-lg example">
                        <?php foreach ($MatrizCargos as $Cargo){
                            
                        ?>
                        
                       
                            <?php
                            echo '<option value='.$Cargo->getIdCargo().'>'.$Cargo->getNombreCargo().'</option>';
                        ?>
                            
                           <?php
                        }?>
                             <!--<option value="NULL" selected="selected">Encargado Sin Asignar</option> -->
                        </select>
                        <!--<input type="text" name="txtnombrearea" id="nombre" class='form-control' maxlength="50">-->
                    </div>
                    <br>
                    <br>

                    <br>
                    <center>
                        <br>
                        <br>

                        <input type="submit" style="font-family:'Maiandra GD'" value="Enviar Datos Para Hacer Crud" id="enviar" style="text-align: center;">
                        <br>
                    </center>
                    <br>


                </div>
            </form>

        </div>
    </div>

</body>
</html>
